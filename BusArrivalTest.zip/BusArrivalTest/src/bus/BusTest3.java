package bus;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.*;

public class BusTest3 {

    private static final String SERVICE_KEY = "5a4469982493d91252147da99404ed2e3f2905a5e7ca77f03d55fa557620cf54";
    private static final String CITY_CODE = "32010";

    private static final String NODE_HALLYM_TO_STATION = "CCB250002127";   // 한림대 → 춘천역
    private static final String NODE_STATION_TO_HALLYM = "CCB250001357";   // 춘천역 → 한림대

    private static final String[] BUS300_TIMETABLE = {
        "06:40","07:10","07:40","08:10","08:30","09:00","09:30","09:45",
        "10:00","10:10","10:20","10:40","11:20","12:00","12:40","13:20",
        "13:40","14:00","14:30","15:00","15:15","15:30","15:45","16:00",
        "16:20","16:50","17:05","17:20","17:35","17:50","18:30","19:00",
        "19:15","19:30","19:45","20:00","20:30","21:00","21:15","21:30",
        "21:45","21:55"
    };

    private static final String[] SHUTTLE_TO_HALLYM = {
        "08:05","08:25","08:30","08:45","09:00","09:15","09:20","09:45",
        "10:00","10:15","10:25","10:45"
    };

    private static final String[] SHUTTLE_TO_STATION = {
        "17:40", "18:10", "19:00"
    };

    // ===================================================================
    // 🔵 경춘선 일반 + 급행 시간표 (평일)
    // ===================================================================
    private static final String[][] GYEONGCHUN = {
        {"05:00", "청량리", "일반"},
        {"05:26", "청량리", "일반"},
        {"05:51", "상봉",   "일반"},
        {"06:12", "청량리", "급행"},
        {"06:23", "상봉",   "일반"},
        {"06:42", "상봉",   "일반"},
        {"07:01", "광운대", "일반"},
        {"07:25", "상봉",   "일반"},
        {"07:51", "청량리", "일반"},
        {"08:16", "청량리", "일반"},
        {"08:38", "청량리", "일반"},
        {"08:56", "상봉",   "일반"},
        {"09:26", "상봉",   "일반"},
        {"09:43", "상봉",   "일반"},
        {"10:02", "상봉",   "일반"},
        {"10:31", "상봉",   "일반"},
        {"10:55", "상봉",   "일반"},
        {"11:22", "상봉",   "일반"},
        {"11:48", "상봉",   "일반"},
        {"12:02", "상봉",   "일반"},
        {"12:19", "청량리", "일반"},
        {"12:48", "상봉",   "일반"},
        {"13:20", "상봉",   "일반"},
        {"13:45", "상봉",   "일반"},
        {"14:02", "상봉",   "일반"},
        {"14:30", "상봉",   "일반"},
        {"14:53", "상봉",   "일반"},
        {"15:10", "청량리", "일반"},
        {"15:45", "상봉",   "일반"},
        {"16:06", "상봉",   "일반"},
        {"16:27", "상봉",   "일반"},
        {"16:44", "상봉",   "일반"},
        {"17:12", "청량리", "일반"},
        {"17:29", "상봉",   "일반"},
        {"17:50", "상봉",   "일반"},
        {"18:19", "상봉",   "일반"},
        {"18:44", "광운대", "일반"},
        {"19:16", "상봉",   "일반"},
        {"19:45", "상봉",   "일반"},
        {"20:12", "상봉",   "일반"},
        {"20:27", "청량리", "일반"},
        {"20:51", "상봉",   "일반"},
        {"21:07", "상봉",   "일반"},
        {"21:28", "상봉",   "일반"},
        {"21:47", "상봉",   "일반"},
        {"21:59", "청량리", "일반"},
        {"22:20", "상봉",   "일반"},
        {"22:44", "상봉",   "일반"},
        {"23:05", "평내호평", "일반"},
        {"23:30", "평내호평", "일반"}
    };

    // ===================================================================
    // 🔵 ITX-청춘 시간표
    // ===================================================================
    private static final String[][] ITX = {
        {"06:07", "용산"},
        {"06:54", "용산"},
        {"07:21", "용산"},
        {"08:11", "용산"},
        {"09:22", "용산"},
        {"10:23", "용산"},
        {"11:16", "용산"},
        {"12:14", "용산"},
        {"13:07", "용산"},
        {"14:06", "용산"},
        {"15:29", "용산"},
        {"16:12", "용산"},
        {"17:03", "용산"},
        {"18:14", "용산"},
        {"18:56", "용산"},
        {"19:37", "용산"},
        {"21:12", "용산"},
        {"22:14", "용산"}
    };

    public static void main(String[] args) {

        System.out.println("\n==============================");
        System.out.println("🚏 한림대 → 춘천역 방향");
        System.out.println("==============================");
        printBusInfo(NODE_HALLYM_TO_STATION);

        System.out.println("\n==============================");
        System.out.println("🚏 춘천역 → 한림대 방향");
        System.out.println("==============================");
        printBusInfo(NODE_STATION_TO_HALLYM);

        System.out.println("\n==============================");
        System.out.println("🚆 경춘선 출발 정보(춘천역)");
        System.out.println("==============================");
        printGyeongchun();

        System.out.println("\n==============================");
        System.out.println("🚄 ITX-청춘 출발 정보(춘천역)");
        System.out.println("==============================");
        printITX();
    }

    // ===================================================================
    // 정류장 전체 출력
    // ===================================================================
    private static void printBusInfo(String nodeId) {
        Map<String, String> results = getRealTimeArrivals(nodeId);

        if (results.isEmpty()) {
            System.out.println("❌ 실시간 도착 정보 없음");
        } else {
            for (String bus : results.keySet()) {
                System.out.println("------------------------------");
                System.out.println("버스 번호: " + bus);
                System.out.println(results.get(bus));
            }
        }

        if (nodeId.equals(NODE_HALLYM_TO_STATION)) {
            System.out.println("------------------------------");
            System.out.println("버스 번호: 한림대 셔틀버스(한림대 → 춘천역)");
            printShuttle(SHUTTLE_TO_STATION, 5);
        }

        if (nodeId.equals(NODE_STATION_TO_HALLYM)) {
            System.out.println("------------------------------");
            System.out.println("버스 번호: 300");
            print300BusInfo();

            System.out.println("------------------------------");
            System.out.println("버스 번호: 한림대 셔틀버스(춘천역 → 한림대)");
            printShuttle(SHUTTLE_TO_HALLYM, 5);
        }
    }

    // ===================================================================
    // 🔵 경춘선 출력
    // ===================================================================
    private static void printGyeongchun() {
        LocalTime now = LocalTime.now();
        DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm");

        for (String[] row : GYEONGCHUN) {
            LocalTime t = LocalTime.parse(row[0], f);
            if (t.isAfter(now)) {
                long sec = java.time.Duration.between(now, t).getSeconds();
                System.out.println("다음 열차: " + row[0] + " → " + row[1]);
                System.out.println("종류: " + row[2]);
                System.out.println("출발까지: " + formatTime(sec));
                return;
            }
        }
        System.out.println("오늘 남은 경춘선 없음");
    }

    // ===================================================================
    // 🔵 ITX 출력
    // ===================================================================
    private static void printITX() {
        LocalTime now = LocalTime.now();
        DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm");

        for (String[] row : ITX) {
            LocalTime t = LocalTime.parse(row[0], f);
            if (t.isAfter(now)) {
                long sec = java.time.Duration.between(now, t).getSeconds();
                System.out.println("다음 ITX: " + row[0] + " → " + row[1]);
                System.out.println("출발까지: " + formatTime(sec));
                return;
            }
        }
        System.out.println("오늘 남은 ITX 없음");
    }

    private static void printShuttle(String[] timetable, int warnMinute) {
        LocalTime now = LocalTime.now();
        DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm");

        ArrayList<LocalTime> times = new ArrayList<>();
        for (String t : timetable) times.add(LocalTime.parse(t, f));

        LocalTime next = null;
        for (LocalTime t : times) {
            if (t.isAfter(now)) {
                next = t;
                break;
            }
        }

        if (next == null) {
            System.out.println("오늘 남은 셔틀버스 없음");
            return;
        }

        long secondsLeft = java.time.Duration.between(now, next).getSeconds();
        long minutes = secondsLeft / 60;

        System.out.println("출발 예정: " + next.format(f));
        if (minutes < warnMinute) {
            System.out.println("⏰ 곧 출발(" + warnMinute + "분)");
        } else {
            System.out.println("출발까지: " + formatTime(secondsLeft));
        }
    }

    private static void print300BusInfo() {
        LocalTime now = LocalTime.now();
        DateTimeFormatter f = DateTimeFormatter.ofPattern("HH:mm");

        ArrayList<LocalTime> times = new ArrayList<>();
        for (String t : BUS300_TIMETABLE) times.add(LocalTime.parse(t, f));

        for (LocalTime t : times) {
            if (t.isAfter(now)) {
                long sec = java.time.Duration.between(now, t).getSeconds();
                System.out.println("차고 출발 예정: " + t.format(f));
                System.out.println("출발까지: " + formatTime(sec));
                return;
            }
        }
        System.out.println("오늘 남은 300번 없음");
    }

    private static Map<String, String> getRealTimeArrivals(String nodeId) {
        Map<String, String> busInfoMap = new LinkedHashMap<>();

        try {
            String urlStr =
                "http://apis.data.go.kr/1613000/ArvlInfoInqireService/getSttnAcctoArvlPrearngeInfoList"
                + "?serviceKey=" + SERVICE_KEY
                + "&pageNo=1"
                + "&numOfRows=50"
                + "&cityCode=" + CITY_CODE
                + "&nodeId=" + nodeId
                + "&_type=xml";

            String xml = request(urlStr);

            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.parse(new java.io.ByteArrayInputStream(xml.getBytes("UTF-8")));

            NodeList items = doc.getElementsByTagName("item");

            for (int i = 0; i < items.getLength(); i++) {
                Element item = (Element) items.item(i);

                String routeno = getTagValue("routeno", item);
                String arrtimeStr = getTagValue("arrtime", item);
                String stationcnt = getTagValue("arrprevstationcnt", item);

                long sec = 0;
                try { sec = Long.parseLong(arrtimeStr); } catch (Exception ignored) {}

                String result;

                if (sec < 70) {
                    result = "남은 시간: ⏰ 곧 도착(1분)\n" +
                             "남은 정거장 수: " + stationcnt;
                } else {
                    result = "남은 시간: " + formatTime(sec) + "\n" +
                             "남은 정거장 수: " + stationcnt;
                }

                busInfoMap.put(routeno, result);
            }

        } catch (Exception e) {
            System.out.println("❌ 실시간 정보 파싱 실패");
        }

        return busInfoMap;
    }

    private static String request(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "UTF-8"));

            StringBuilder result = new StringBuilder();
            String line;

            while ((line = br.readLine()) != null) {
                result.append(line);
            }

            br.close();
            conn.disconnect();

            return result.toString();

        } catch (Exception e) {
            return "";
        }
    }

    private static String getTagValue(String tag, Element element) {
        NodeList nl = element.getElementsByTagName(tag);
        if (nl.getLength() == 0) return "";
        Node node = nl.item(0).getFirstChild();
        return node != null ? node.getNodeValue() : "";
    }

    private static String formatTime(long sec) {
        long hours = sec / 3600;
        long minutes = (sec % 3600) / 60;
        long seconds = sec % 60;

        StringBuilder sb = new StringBuilder();
        if (hours > 0) sb.append(hours).append("시간 ");
        if (minutes > 0) sb.append(minutes).append("분 ");
        sb.append(seconds).append("초");

        return sb.toString().trim();
    }
}

